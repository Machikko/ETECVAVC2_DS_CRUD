<?php include 'includes/header.php'; ?>

<h2>Cadastrar Produto</h2>

<form action="inserir.php" method="POST">

    <label>Nome do produto</label>
    <input type="text" name="nome" required>

    <label>Estoque</label>
    <input type="number" name="estoque" required>

    <button type="submit">Salvar</button>

</form>

<?php include 'includes/footer.php'; ?>