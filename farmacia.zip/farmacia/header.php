<link rel="stylesheet" href="css/style.css">
<header class="topo">

    <div class="container">

        <div class="logo">
            Farmácia Sistema
        </div>

        <nav class="menu">
            <a href="index.php">Início</a>
            <a href="cadastro.php">Cadastrar</a>
            <a href="#">Produtos</a>
        </nav>

    </div>

</header>