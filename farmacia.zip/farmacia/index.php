<?php

    require_once 'config/conexao.php';
// O ID que queremos buscar
$idBuscado = 2;

// 2. PREPARAR: Note o uso do ":id" (um apelido/placeholder)
// Isso impede que alguém tente injetar códigos maliciosos no seu SQL
$sql = "SELECT * FROM produtos WHERE id = :id";
$stmt = $conexao->prepare($sql);

// 3. EXECUTAR: Passamos o valor real para o apelido :id
$stmt->execute([':id' => $idBuscado]);

// 4. BUSCAR: Como o ID é único, usamos fetch() em vez de fetchAll()
// O FETCH_ASSOC serve para que o resultado venha como um array ['campo' => 'valor']
$contato = $stmt->fetch(PDO::FETCH_ASSOC);

// 5. MOSTRAR OS DADOS
if ($contato) {
    echo "Nome: " . $contato['nome'] . "<br>";
    echo "Número: " . $contato['numero'];
} else {
    echo "Contato com ID $idBuscado não encontrado.";
}
?>