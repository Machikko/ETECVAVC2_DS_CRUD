<?php

require_once 'config/conexao.php';

$nome = $_POST['nome'];
$estoque = $_POST['estoque'];

$sql = "INSERT INTO produtos (nome, estoque)
        VALUES (:nome, :estoque)";

$stmt = $conexao->prepare($sql);

$stmt->execute([
    ':nome' => $nome,
    ':estoque' => $estoque
]);

if ($conexao->lastInsertId()) {
    echo "Sucesso! Produto cadastrado com ID: " . $conexao->lastInsertId();
}

echo "<br><a href='cadastro.php'>Voltar</a>";

?>